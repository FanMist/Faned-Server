VISOR
Modification of Snoutx10k, original by geartrooper, modified by Megagun.

INSTALLATION: backup your original Snoutx10k folder in packages/models and then replace it with the folder in the archive.
